[UFT v4.3]

##################################################################

    This file is part of the "Universal Flasher Tool" Template.

                 PLEASE, DON'T DELETE THIS FILE

##################################################################




#######################   L I C E N S E ###########################

Universal Flasher tool is free software: you can redistribute it 
and/or modify it under the terms of the GNU General Public License
as published by the Free Software Foundation, either version 3 of 
the License, or any later version.

Universal Flasher tool is distributed in the hope that it will be 
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License for more details: 
<http://www.gnu.org/licenses/>


Do not modify the file header updater-script in order to maintain 
the original provisions of the Universal Flasher Tool:


	ui_print("       <<-----------------------------");
	ui_print("        UNIVERSAL FLASHER TOOL  v.X.X");
	ui_print("           by  JRsoft & Intronauta");
	ui_print("           - - - - - - - - - - - -    ");
	ui_print("          based in <vrtheme System>");
	ui_print("       ----------------------------->>");



##################### D I S C L A I M E R #########################

>> Yeah, our english is not very good and can be confusing at times
so be comprehensive, we did our best! ;)

>> Check and read the instructions carefully before doing anything. 

>> UFT is designed to be configured from the UFT.config file and 
not having to touch code inside the updater-script or scripts. 

>> UFT.config lets you configure and adapt the process to your 
needs. If you need special options or modify code to adapt it to 
your phone/system, let us know to include the option. It will be 
useful for more people ;)

>> UFT is far from being perfect and can cause problems. We have 
tried to provide a "friendly" code away from being optimized, 
elegant or don't be redundant. Check the code and take decisions. 

>> UFT is under continuous development. Check on the official 
thread (check in the "ABOUT" section) that you are working with the
latest version of UFT.Otherwise you may have compatibility problems.


>> We are not responsible for any misuse or mishandling of UFT.




################## H O W    U F T   W O R K S #####################

Very simple:


>> Put in "/XTRAS" folder files that you want to add recreating 
their full paths. Note that /XTRAS is equivalent to root path in 
the internal memory. 


  e.g: 

    /XTRAS/system/framework/framework-res.apk
    /XTRAS/system/etc/gps.conf
    /XTRAS/sdcard/Wallpapers/xxxx.jpeg
    /XTRAS/data/app/Youtube.apk
    /XTRAS/preload/symlink/system/app/VideoPlayer.apk
    /XTRAS/whateverfolder/whateverfile



>> Put in "/MORPH" folder your "morph themes". Note that /MORPH is
equivalent to root path in the internal memory and you must rename
folders like the apk but with extension instead the metamorph form.
MORPH works with .apk and .jar file types. 


  [[[[[  CAUTION, ARMAGEDDON, KRAKEN IS COMMING, TEETS!!  ]]]]]

          [ DON'T APPLY MORPH TO MARKET/SIGNED APPS ]
                      [ YOU ARE ADVICED ]


  e.g:
 
    /MORPH/system/app/Settings.apk/res/drawable-hdpi/***.png
    /MORPH/system/app/Settings.apk/classes.dex
    /MORPH/system/framework/framework-res.apk/resources.arsc
    /MORPH/system/framework/services.jar/classes.dex
    /MORPH/data/app/****.apk/res/drawable/**.png
    /MORPH/preload/symlink/system/app/Clock.apk/resources.arsc
    /MORPH/whateverfolder/****.apk/*
  



>> It's very important that you take a look to the UFT.config file
and enable or disable features and/or set special commands if you
need it.


>> Don't forget to set in UFT.config what is the real path to your
sdcard in the recovery. Don't set the symlink to /sdcard, set the
real path!!

These are the most commons paths: 

    /emmc      /sdcard       /data/media       /data/media/0

Keep in mind that the new devices uses /data/media as internal 
sdcard, but since android 4.2 and the multiuser system, it's very
possibly that you need set /data/media/0 or /data/media/1 
depending of the user you are.

       [[ You must know how your recovery or system works ]] 
       [[    or you'll lose the backup after reboot!!!    ]]

And remember that it's not necessary modify the generic "/sdcard"
folder name in MORPH or XTRAS, you could let to the process rename
it in function of this config.


>> Be sure you know howto mount the neccesary partitions to work in
your device. If you got errors mounting partitions or need to work
with non-standard partitions, setup the UFT.config and add, adapt 
or modify the standard commands. Please, don't add mount commands 
in the updater-script, you must do it in UFT.config, we need this 
commands for the backup!! ;).


>> Flash and enjoy!!



########################## L O G S ###############################

>> There're two logs, one in /cache/UFT.log which will only be 
created if there was problems mounting partitions or detecting the
sdcard, and another related to the process itself in the 
/UniversalFlasher folder, which will only be created if is enabled
in UFT.config. 


>> Remember that the recovery usually creates another one after 
flash a zip in the /cache/recovery or /tmp folder. This log 
contains  deeper info about the process. It could be interesting 
for debugging tasks.





################## K N O W N   E R R O R S #######################


>> If you get (Status 0) error flashing, you need an update-binary 
specific for your terminal. You must look for and extract the
"/META-INF/com/google/android/update-binary" file inside a zip 
compatible with your terminal and replace it in the same path into 
the UFT template. You also can consider to replace the whole 
META-INF folder in the MOD with the other compatible, except the 
updater-script!!

>> In some recoveries the on-screen log may suffer glitches, be 
displayed oversized and be unreadable. You should take a look at 
the logs to get info about the process.

>> If you get errors or need help, please, contact us and upload
as many logs as possible to the UFT thread (link located above)





######################### A B O U T ###############################

>> Don't forget to check for more info, updates, requests or error 
reports related to "Universal Flasher Tool" here:

http://www.htcmania.com/showthread.php?t=258333

(you can do it in english, spanish or spanglish, don't worry :P)






####################### C R E D I T S #############################

>> "Universal Flasher Tool" is based in the "vrtheme system":
http://forum.xda-developers.com/showthread.php?t=1207017






###################### T H A N K S   T O ##########################

>> "Stericson" for the original "Metamorph" system
>> "Core Utilities" for the tar binary
>> "Blades" for compiled a dinamic binary of 7z
>> "lovetide" for compiled the current static binary of 7z
>> Whoever compiled the "zip" binary
>> TeamWin for recompile zipalign as a static binary
>> Testers, especially to:
   "SuperCocoV6.5@htcmania", "lexullde@htcmania", "shayne77@xda",
   "vvaleta@htcmania", "klander@htcspain", "eladios@htcmania",
.  "trabas@htcmania", "audalecio@htcmania", "666roi666@htcmania" 
>> "D.O.C@xda" for helping with the translations.
